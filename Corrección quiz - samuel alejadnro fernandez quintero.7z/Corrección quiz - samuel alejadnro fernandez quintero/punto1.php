<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Shop Homepage - Start Bootstrap Template</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
        <header class="bg-dark py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">PUNTO 1</h1>
                    <p class="lead fw-normal text-white-50 mb-0">Samuel Alejandro Fernandez Quintero</p><br>
                    <p class="lead fw-normal text-white-50 mb-0">11-2</p><br>
                </div>
            </div>
        </header><br><br>
    
        <form method='post' action=''>
            <div class="input-group">
            <span class="input-group-text" id="basic-addon3">Ingrese la edad: </span>
            <input type="number" class="form-control" name="edad" aria-describedby="basic-addon3 basic-addon4" required><br><br>
            <button type='submit' class='btn btn-dark'>Revisar</button>
            </div>
        </form>


    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $edad = $_POST["edad"];
        $precio = 0;

        if ($edad < 4) {
            $precio = 0;

        } elseif ($edad >= 4 && $edad <= 18) {
            $precio = 5000;

        } else {
            $precio = 10000;
        }

        echo "<p>El precio de la entrada es: $$precio pesos</p>";
    }
    ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>